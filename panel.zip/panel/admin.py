from django.contrib import admin
from .models import Post

# Registro básico do modelo Post
admin.site.register(Post)