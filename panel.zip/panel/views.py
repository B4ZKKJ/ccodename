from django.shortcuts import render
from django.http import HttpResponse
from .models import Post

def painel(request, inf, cnt):
    Post.objects.create(title=inf, content=cnt)
    return HttpResponse(f'Objeto criado!')
